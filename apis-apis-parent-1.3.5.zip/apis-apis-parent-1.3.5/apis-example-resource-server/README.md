Example Resource Server
======
The Example Resource Server is build using [Dropwizard] (http://dropwizard.codahale.com/). It demonstrates a Resource Server depending on the Authorization Server to validate tokens.

See the documentation in the [README.md](https://github.com/OpenConextApps/apis/blob/master/README.md) in the root project for detailed instructions on how to start the Example Resource Server. 

