Apis Distribution
======
This project is optionally and not part of the core. It is used for making an environment independent tar file for distribution including the properties file for 'steering' runtime behaviour.