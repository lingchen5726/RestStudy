1、当前mongodb需要使用默认端口
2、如果不使用默认端口，需要将conf文件中的admin改为IP:PORT。

	